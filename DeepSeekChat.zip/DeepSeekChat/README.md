# DeepSeek Chat (Android)

1. Create a new GitHub repo, upload ALL files (including the `.github` folder).
2. Go to Actions > "Build APK" > wait for green check (~4-6 min).
3. Open the run > Artifacts > download DeepSeekChat-APK, unzip, install app-debug.apk.
4. Open the app, paste your DeepSeek API key (platform.deepseek.com), Save.

الخطوات بالعربية: أنشئ مستودعاً على GitHub، ارفع كل الملفات (مع مجلد .github)، افتح تبويب Actions وانتظر اكتمال البناء، ثم نزّل ملف APK من Artifacts وثبّته، وأدخل مفتاح DeepSeek في الإعدادات.
