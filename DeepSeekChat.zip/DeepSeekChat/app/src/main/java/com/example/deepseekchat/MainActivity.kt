package com.example.deepseekchat

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class Msg(val role: String, val content: String, val error: Boolean = false)

data class Provider(
    val id: String,
    val label: String,
    val chatUrl: String,
    val modelsUrl: String,
    val defaultModel: String,
    val anthropic: Boolean = false,
    val hint: String = ""
)

val PROVIDERS = listOf(
    Provider(
        "deepseek", "DeepSeek",
        "https://api.deepseek.com/chat/completions",
        "https://api.deepseek.com/models",
        "deepseek-chat",
        hint = "Key: platform.deepseek.com"
    ),
    Provider(
        "openai", "ChatGPT (OpenAI)",
        "https://api.openai.com/v1/chat/completions",
        "https://api.openai.com/v1/models",
        "chat-latest",
        hint = "Key: platform.openai.com"
    ),
    Provider(
        "gemini", "Gemini (Google) - free tier",
        "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
        "https://generativelanguage.googleapis.com/v1beta/openai/models",
        "gemini-3.8-flash",
        hint = "FREE key: aistudio.google.com/apikey"
    ),
    Provider(
        "claude", "Claude (Anthropic)",
        "https://api.anthropic.com/v1/messages",
        "https://api.anthropic.com/v1/models?limit=100",
        "claude-sonnet-5-5",
        anthropic = true,
        hint = "Key: console.anthropic.com"
    ),
    Provider(
        "qwen", "Qwen (Alibaba, Intl)",
        "https://dashscope-intl.aliyuncs.com/compatible-mode/v1/chat/completions",
        "https://dashscope-intl.aliyuncs.com/compatible-mode/v1/models",
        "qwen-plus",
        hint = "Key: modelstudio.console.alibabacloud.com (free quota for new users)"
    ),
    Provider(
        "qwen_cn", "Qwen (Alibaba, China)",
        "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
        "https://dashscope.aliyuncs.com/compatible-mode/v1/models",
        "qwen-plus",
        hint = "Key: bailian.console.aliyun.com"
    ),
    Provider(
        "openrouter", "OpenRouter - many FREE models",
        "https://openrouter.ai/api/v1/chat/completions",
        "https://openrouter.ai/api/v1/models",
        "meta-llama/llama-3.3-70b-instruct:free",
        hint = "FREE key: openrouter.ai/keys - free models end with :free"
    ),
    Provider(
        "groq", "Groq - free tier",
        "https://api.groq.com/openai/v1/chat/completions",
        "https://api.groq.com/openai/v1/models",
        "llama-3.3-70b-versatile",
        hint = "FREE key: console.groq.com/keys"
    ),
    Provider(
        "mistral", "Mistral - free tier",
        "https://api.mistral.ai/v1/chat/completions",
        "https://api.mistral.ai/v1/models",
        "mistral-small-latest",
        hint = "FREE tier key: console.mistral.ai"
    )
)

private const val SYSTEM_PROMPT = "You are a helpful assistant."

private val client = OkHttpClient.Builder()
    .connectTimeout(30, TimeUnit.SECONDS)
    .readTimeout(180, TimeUnit.SECONDS)
    .writeTimeout(30, TimeUnit.SECONDS)
    .build()

class ApiException(val code: Int, message: String) : Exception(message)

private fun errorDetail(text: String): String = runCatching {
    val t = text.trim()
    val obj = if (t.startsWith("[")) JSONArray(t).getJSONObject(0) else JSONObject(t)
    obj.getJSONObject("error").getString("message")
}.getOrDefault(text.take(300))

private fun callApi(p: Provider, key: String, model: String, history: List<Msg>): Result<String> =
    try {
        Result.success(callApiOrThrow(p, key, model, history))
    } catch (e: Exception) {
        Result.failure(e)
    }

private fun callApiOrThrow(p: Provider, key: String, model: String, history: List<Msg>): String {
    val msgs = JSONArray()
    if (!p.anthropic) {
        msgs.put(JSONObject().put("role", "system").put("content", SYSTEM_PROMPT))
    }
    history.filter { !it.error }.forEach {
        msgs.put(JSONObject().put("role", it.role).put("content", it.content))
    }

    val json = JSONObject().put("model", model).put("messages", msgs)
    val builder = Request.Builder().url(p.chatUrl)
    if (p.anthropic) {
        json.put("max_tokens", 4096).put("system", SYSTEM_PROMPT)
        builder.addHeader("x-api-key", key.trim())
        builder.addHeader("anthropic-version", "2023-06-01")
    } else {
        json.put("stream", false)
        builder.addHeader("Authorization", "Bearer ${key.trim()}")
    }
    val req = builder
        .post(json.toString().toRequestBody("application/json".toMediaType()))
        .build()

    // Retry automatically on temporary errors (overloaded / rate limited).
    for (attempt in 0..3) {
        val (code, text) = client.newCall(req).execute().use { resp ->
            resp.code to resp.body?.string().orEmpty()
        }
        if (code in 200..299) {
            val root = JSONObject(text)
            return if (p.anthropic) {
                val blocks = root.getJSONArray("content")
                buildString {
                    for (i in 0 until blocks.length()) {
                        val b = blocks.getJSONObject(i)
                        if (b.optString("type") == "text") append(b.optString("text"))
                    }
                }.trim()
            } else {
                root.getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").getString("content").trim()
            }
        }
        val temporary = code == 429 || code == 500 || code == 502 || code == 503 || code == 504
        if (temporary && attempt < 3) {
            Thread.sleep(3000L * (attempt + 1))
            continue
        }
        throw ApiException(code, "HTTP $code: ${errorDetail(text)}")
    }
    throw Exception("Request failed")
}

private fun fetchModels(p: Provider, key: String): Result<List<String>> = runCatching {
    val b = Request.Builder().url(p.modelsUrl).get()
    if (p.anthropic) {
        b.addHeader("x-api-key", key.trim())
        b.addHeader("anthropic-version", "2023-06-01")
    } else if (key.isNotBlank()) {
        b.addHeader("Authorization", "Bearer ${key.trim()}")
    }
    client.newCall(b.build()).execute().use { resp ->
        val text = resp.body?.string().orEmpty()
        if (!resp.isSuccessful) throw Exception("HTTP ${resp.code}: ${text.take(200)}")
        val arr = JSONObject(text).getJSONArray("data")
        (0 until arr.length())
            .map { arr.getJSONObject(it).getString("id").removePrefix("models/") }
            .distinct()
            .sorted()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme { Surface(Modifier.fillMaxSize()) { ChatScreen() } }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE) }

    var providerId by remember { mutableStateOf(prefs.getString("provider", "deepseek") ?: "deepseek") }
    var keys by remember {
        mutableStateOf(PROVIDERS.associate { p ->
            val legacy = if (p.id == "deepseek") prefs.getString("key", "") ?: "" else ""
            p.id to (prefs.getString("key_${p.id}", legacy) ?: "")
        })
    }
    var models by remember {
        mutableStateOf(PROVIDERS.associate { p ->
            p.id to (prefs.getString("model_${p.id}", p.defaultModel) ?: p.defaultModel)
        })
    }
    val provider = PROVIDERS.firstOrNull { it.id == providerId } ?: PROVIDERS[0]
    val apiKey = keys[provider.id].orEmpty()
    val model = models[provider.id].orEmpty().ifBlank { provider.defaultModel }

    val messages = remember { mutableStateListOf<Msg>() }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(apiKey.isBlank()) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size, loading) {
        val count = messages.size + if (loading) 1 else 0
        if (count > 0) listState.animateScrollToItem(count - 1)
    }

    fun send() {
        val text = input.trim()
        if (text.isEmpty() || loading) return
        if (apiKey.isBlank()) { showSettings = true; return }
        messages.add(Msg("user", text))
        input = ""
        loading = true
        val history = messages.toList()
        val p = provider
        val k = apiKey
        val m = model
        scope.launch {
            val result = withContext(Dispatchers.IO) { callApi(p, k, m, history) }
            result.fold(
                onSuccess = { messages.add(Msg("assistant", it)) },
                onFailure = { e ->
                    val modelProblem = e is ApiException && (e.code == 404 || e.code == 400)
                    val hint = if (modelProblem) "\n\n👉 ⚙️ → تحميل النماذج / Load models, then pick a current model." else ""
                    messages.add(Msg("assistant", "⚠️ ${e.message ?: "Unknown error"}$hint", error = true))
                    if (e is ApiException && e.code == 404) showSettings = true
                }
            )
            loading = false
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        TopAppBar(
            title = {
                Column {
                    Text(provider.label, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                    Text(model, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                }
            },
            actions = {
                TextButton(onClick = { messages.clear() }) { Text("🗑") }
                TextButton(onClick = { showSettings = true }) { Text("⚙️") }
            }
        )

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { m ->
                val mine = m.role == "user"
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = when {
                            m.error -> MaterialTheme.colorScheme.errorContainer
                            mine -> MaterialTheme.colorScheme.primaryContainer
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        },
                        modifier = Modifier.widthIn(max = 320.dp)
                    ) {
                        SelectionContainer {
                            Text(
                                m.content,
                                Modifier.padding(12.dp),
                                style = LocalTextStyle.current.copy(textDirection = TextDirection.Content)
                            )
                        }
                    }
                }
            }
            if (loading) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("…")
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("اكتب رسالتك / Type a message") },
                maxLines = 5
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { send() }, enabled = !loading && input.isNotBlank()) { Text("➤") }
        }
    }

    if (showSettings) {
        var pDraft by remember { mutableStateOf(provider.id) }
        val kDraft = remember { mutableStateMapOf<String, String>().apply { putAll(keys) } }
        val mDraft = remember { mutableStateMapOf<String, String>().apply { putAll(models) } }
        val modelLists = remember { mutableStateMapOf<String, List<String>>() }
        var menuOpen by remember { mutableStateOf(false) }
        var loadingModels by remember { mutableStateOf(false) }
        var modelErr by remember { mutableStateOf<String?>(null) }
        var freeOnly by remember { mutableStateOf(false) }
        val canDismiss = apiKey.isNotBlank()
        val pObj = PROVIDERS.firstOrNull { it.id == pDraft } ?: PROVIDERS[0]

        fun loadModels(target: Provider) {
            val key = kDraft[target.id].orEmpty()
            loadingModels = true
            modelErr = null
            scope.launch {
                val r = withContext(Dispatchers.IO) { fetchModels(target, key) }
                r.fold(
                    onSuccess = { modelLists[target.id] = it },
                    onFailure = { modelErr = it.message ?: "Error" }
                )
                loadingModels = false
            }
        }

        LaunchedEffect(pDraft) {
            val has = kDraft[pDraft].orEmpty().isNotBlank() || pDraft == "openrouter"
            if (has && modelLists[pDraft] == null) loadModels(pObj)
        }

        AlertDialog(
            onDismissRequest = { if (canDismiss) showSettings = false },
            title = { Text("الإعدادات / Settings") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Box {
                        OutlinedButton(onClick = { menuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(pObj.label + "  ▾")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            PROVIDERS.forEach { p ->
                                DropdownMenuItem(
                                    text = { Text(p.label) },
                                    onClick = { pDraft = p.id; menuOpen = false; modelErr = null }
                                )
                            }
                        }
                    }
                    if (pObj.hint.isNotBlank()) {
                        Text(pObj.hint, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 4.dp))
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = kDraft[pDraft].orEmpty(),
                        onValueChange = { kDraft[pDraft] = it },
                        label = { Text("API Key") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = mDraft[pDraft].orEmpty(),
                        onValueChange = { mDraft[pDraft] = it },
                        label = { Text("Model") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(
                            enabled = !loadingModels,
                            onClick = { loadModels(pObj) }
                        ) { Text(if (loadingModels) "…" else "تحميل النماذج / Load models") }
                        if (pObj.id == "openrouter") {
                            Checkbox(checked = freeOnly, onCheckedChange = { freeOnly = it })
                            Text("Free only")
                        }
                    }
                    modelErr?.let {
                        Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                    }
                    val all = modelLists[pDraft].orEmpty()
                    if (all.isNotEmpty()) {
                        val typed = mDraft[pDraft].orEmpty()
                        val shown = all.filter {
                            (!freeOnly || pObj.id != "openrouter" || it.endsWith(":free")) &&
                                (typed.isBlank() || it.contains(typed, ignoreCase = true))
                        }.take(40)
                        Text(
                            "${shown.size} / ${all.size}  (اكتب للتصفية / type to filter)",
                            style = MaterialTheme.typography.labelSmall
                        )
                        shown.forEach { id ->
                            Text(
                                id,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { mDraft[pDraft] = id }
                                    .padding(vertical = 8.dp),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    keys = PROVIDERS.associate { it.id to kDraft[it.id].orEmpty().trim() }
                    models = PROVIDERS.associate { it.id to mDraft[it.id].orEmpty().trim() }
                    providerId = pDraft
                    val e = prefs.edit().putString("provider", pDraft)
                    PROVIDERS.forEach {
                        e.putString("key_${it.id}", keys[it.id].orEmpty())
                        e.putString("model_${it.id}", models[it.id].orEmpty())
                    }
                    e.apply()
                    showSettings = false
                }) { Text("حفظ / Save") }
            },
            dismissButton = {
                if (canDismiss) TextButton(onClick = { showSettings = false }) { Text("إلغاء / Cancel") }
            }
        )
    }
}
