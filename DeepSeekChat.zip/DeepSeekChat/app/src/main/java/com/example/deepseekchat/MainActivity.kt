package com.example.deepseekchat

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class Msg(val role: String, val content: String, val error: Boolean = false)

private val client = OkHttpClient.Builder()
    .connectTimeout(30, TimeUnit.SECONDS)
    .readTimeout(180, TimeUnit.SECONDS)
    .writeTimeout(30, TimeUnit.SECONDS)
    .build()

private fun callApi(key: String, model: String, history: List<Msg>): Result<String> = runCatching {
    val arr = JSONArray()
    arr.put(JSONObject().put("role", "system").put("content", "You are a helpful assistant."))
    history.filter { !it.error }.forEach {
        arr.put(JSONObject().put("role", it.role).put("content", it.content))
    }
    val body = JSONObject()
        .put("model", model)
        .put("messages", arr)
        .put("stream", false)
        .toString()
        .toRequestBody("application/json".toMediaType())

    val req = Request.Builder()
        .url("https://api.deepseek.com/chat/completions")
        .addHeader("Authorization", "Bearer ${key.trim()}")
        .post(body)
        .build()

    client.newCall(req).execute().use { resp ->
        val text = resp.body?.string().orEmpty()
        if (!resp.isSuccessful) {
            val detail = runCatching {
                JSONObject(text).getJSONObject("error").getString("message")
            }.getOrDefault(text.take(300))
            throw Exception("HTTP ${resp.code}: $detail")
        }
        JSONObject(text).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content").trim()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme { Surface(Modifier.fillMaxSize()) { ChatScreen() } }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE) }
    var apiKey by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "deepseek-chat") ?: "deepseek-chat") }
    val messages = remember { mutableStateListOf<Msg>() }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(apiKey.isBlank()) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size, loading) {
        val count = messages.size + if (loading) 1 else 0
        if (count > 0) listState.animateScrollToItem(count - 1)
    }

    fun send() {
        val text = input.trim()
        if (text.isEmpty() || loading) return
        if (apiKey.isBlank()) { showSettings = true; return }
        messages.add(Msg("user", text))
        input = ""
        loading = true
        val history = messages.toList()
        scope.launch {
            val result = withContext(Dispatchers.IO) { callApi(apiKey, model, history) }
            result.fold(
                onSuccess = { messages.add(Msg("assistant", it)) },
                onFailure = { messages.add(Msg("assistant", "⚠️ ${it.message ?: "Unknown error"}", error = true)) }
            )
            loading = false
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        TopAppBar(
            title = { Text("DeepSeek Chat") },
            actions = {
                TextButton(onClick = { messages.clear() }) { Text("🗑") }
                TextButton(onClick = { showSettings = true }) { Text("⚙️") }
            }
        )

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { m ->
                val mine = m.role == "user"
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = when {
                            m.error -> MaterialTheme.colorScheme.errorContainer
                            mine -> MaterialTheme.colorScheme.primaryContainer
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        },
                        modifier = Modifier.widthIn(max = 320.dp)
                    ) {
                        SelectionContainer {
                            Text(m.content, Modifier.padding(12.dp))
                        }
                    }
                }
            }
            if (loading) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("…")
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("اكتب رسالتك / Type a message") },
                maxLines = 5
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { send() }, enabled = !loading && input.isNotBlank()) { Text("➤") }
        }
    }

    if (showSettings) {
        var keyDraft by remember { mutableStateOf(apiKey) }
        var modelDraft by remember { mutableStateOf(model) }
        AlertDialog(
            onDismissRequest = { if (apiKey.isNotBlank()) showSettings = false },
            title = { Text("الإعدادات / Settings") },
            text = {
                Column {
                    OutlinedTextField(
                        value = keyDraft,
                        onValueChange = { keyDraft = it },
                        label = { Text("DeepSeek API Key") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation()
                    )
                    Spacer(Modifier.height(12.dp))
                    listOf("deepseek-chat", "deepseek-reasoner").forEach { name ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = modelDraft == name, onClick = { modelDraft = name })
                            Text(name)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    apiKey = keyDraft.trim()
                    model = modelDraft
                    prefs.edit().putString("key", apiKey).putString("model", model).apply()
                    showSettings = false
                }) { Text("حفظ / Save") }
            }
        )
    }
}
