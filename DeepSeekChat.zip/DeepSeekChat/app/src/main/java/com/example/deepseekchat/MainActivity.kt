package com.example.deepseekchat

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class Msg(val role: String, val content: String, val error: Boolean = false)

data class Provider(
    val id: String,
    val label: String,
    val url: String,
    val defaultModel: String,
    val anthropic: Boolean = false
)

val PROVIDERS = listOf(
    Provider("deepseek", "DeepSeek", "https://api.deepseek.com/chat/completions", "deepseek-chat"),
    Provider("openai", "ChatGPT (OpenAI)", "https://api.openai.com/v1/chat/completions", "gpt-4o-mini"),
    Provider("gemini", "Gemini (Google)", "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", "gemini-2.5-flash"),
    Provider("claude", "Claude (Anthropic)", "https://api.anthropic.com/v1/messages", "claude-sonnet-5-5", anthropic = true),
    Provider("qwen", "Qwen (Alibaba, Intl)", "https://dashscope-intl.aliyuncs.com/compatible-mode/v1/chat/completions", "qwen-plus"),
    Provider("qwen_cn", "Qwen (Alibaba, China)", "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions", "qwen-plus")
)

private const val SYSTEM_PROMPT = "You are a helpful assistant."

private val client = OkHttpClient.Builder()
    .connectTimeout(30, TimeUnit.SECONDS)
    .readTimeout(180, TimeUnit.SECONDS)
    .writeTimeout(30, TimeUnit.SECONDS)
    .build()

private fun callApi(p: Provider, key: String, model: String, history: List<Msg>): Result<String> = runCatching {
    val msgs = JSONArray()
    if (!p.anthropic) {
        msgs.put(JSONObject().put("role", "system").put("content", SYSTEM_PROMPT))
    }
    history.filter { !it.error }.forEach {
        msgs.put(JSONObject().put("role", it.role).put("content", it.content))
    }

    val json = JSONObject().put("model", model).put("messages", msgs)
    val builder = Request.Builder().url(p.url)
    if (p.anthropic) {
        json.put("max_tokens", 4096).put("system", SYSTEM_PROMPT)
        builder.addHeader("x-api-key", key.trim())
        builder.addHeader("anthropic-version", "2023-06-01")
    } else {
        json.put("stream", false)
        builder.addHeader("Authorization", "Bearer ${key.trim()}")
    }
    val req = builder
        .post(json.toString().toRequestBody("application/json".toMediaType()))
        .build()

    client.newCall(req).execute().use { resp ->
        val text = resp.body?.string().orEmpty()
        if (!resp.isSuccessful) {
            val detail = runCatching {
                JSONObject(text).getJSONObject("error").getString("message")
            }.getOrDefault(text.take(300))
            throw Exception("HTTP ${resp.code}: $detail")
        }
        val root = JSONObject(text)
        if (p.anthropic) {
            val blocks = root.getJSONArray("content")
            buildString {
                for (i in 0 until blocks.length()) {
                    val b = blocks.getJSONObject(i)
                    if (b.optString("type") == "text") append(b.optString("text"))
                }
            }.trim()
        } else {
            root.getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content").trim()
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme { Surface(Modifier.fillMaxSize()) { ChatScreen() } }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE) }

    var providerId by remember { mutableStateOf(prefs.getString("provider", "deepseek") ?: "deepseek") }
    var keys by remember {
        mutableStateOf(PROVIDERS.associate { p ->
            val legacy = if (p.id == "deepseek") prefs.getString("key", "") ?: "" else ""
            p.id to (prefs.getString("key_${p.id}", legacy) ?: "")
        })
    }
    var models by remember {
        mutableStateOf(PROVIDERS.associate { p ->
            p.id to (prefs.getString("model_${p.id}", p.defaultModel) ?: p.defaultModel)
        })
    }
    val provider = PROVIDERS.firstOrNull { it.id == providerId } ?: PROVIDERS[0]
    val apiKey = keys[provider.id].orEmpty()
    val model = models[provider.id].orEmpty().ifBlank { provider.defaultModel }

    val messages = remember { mutableStateListOf<Msg>() }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(apiKey.isBlank()) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size, loading) {
        val count = messages.size + if (loading) 1 else 0
        if (count > 0) listState.animateScrollToItem(count - 1)
    }

    fun send() {
        val text = input.trim()
        if (text.isEmpty() || loading) return
        if (apiKey.isBlank()) { showSettings = true; return }
        messages.add(Msg("user", text))
        input = ""
        loading = true
        val history = messages.toList()
        val p = provider
        val k = apiKey
        val m = model
        scope.launch {
            val result = withContext(Dispatchers.IO) { callApi(p, k, m, history) }
            result.fold(
                onSuccess = { messages.add(Msg("assistant", it)) },
                onFailure = { messages.add(Msg("assistant", "⚠️ ${it.message ?: "Unknown error"}", error = true)) }
            )
            loading = false
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        TopAppBar(
            title = {
                Column {
                    Text(provider.label)
                    Text(model, style = MaterialTheme.typography.labelSmall)
                }
            },
            actions = {
                TextButton(onClick = { messages.clear() }) { Text("🗑") }
                TextButton(onClick = { showSettings = true }) { Text("⚙️") }
            }
        )

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { m ->
                val mine = m.role == "user"
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = when {
                            m.error -> MaterialTheme.colorScheme.errorContainer
                            mine -> MaterialTheme.colorScheme.primaryContainer
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        },
                        modifier = Modifier.widthIn(max = 320.dp)
                    ) {
                        SelectionContainer {
                            Text(m.content, Modifier.padding(12.dp))
                        }
                    }
                }
            }
            if (loading) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("…")
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("اكتب رسالتك / Type a message") },
                maxLines = 5
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { send() }, enabled = !loading && input.isNotBlank()) { Text("➤") }
        }
    }

    if (showSettings) {
        var pDraft by remember { mutableStateOf(provider.id) }
        val kDraft = remember { mutableStateMapOf<String, String>().apply { putAll(keys) } }
        val mDraft = remember { mutableStateMapOf<String, String>().apply { putAll(models) } }
        val canDismiss = apiKey.isNotBlank()

        AlertDialog(
            onDismissRequest = { if (canDismiss) showSettings = false },
            title = { Text("الإعدادات / Settings") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    PROVIDERS.forEach { p ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = pDraft == p.id, onClick = { pDraft = p.id })
                            Text(p.label)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = kDraft[pDraft].orEmpty(),
                        onValueChange = { kDraft[pDraft] = it },
                        label = { Text("API Key") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = mDraft[pDraft].orEmpty(),
                        onValueChange = { mDraft[pDraft] = it },
                        label = { Text("Model") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    keys = PROVIDERS.associate { it.id to kDraft[it.id].orEmpty().trim() }
                    models = PROVIDERS.associate { it.id to mDraft[it.id].orEmpty().trim() }
                    providerId = pDraft
                    val e = prefs.edit().putString("provider", pDraft)
                    PROVIDERS.forEach {
                        e.putString("key_${it.id}", keys[it.id].orEmpty())
                        e.putString("model_${it.id}", models[it.id].orEmpty())
                    }
                    e.apply()
                    showSettings = false
                }) { Text("حفظ / Save") }
            },
            dismissButton = {
                if (canDismiss) TextButton(onClick = { showSettings = false }) { Text("إلغاء / Cancel") }
            }
        )
    }
}
